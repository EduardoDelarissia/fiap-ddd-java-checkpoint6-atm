package br.com.fiap.bank.mesa;
import feign.RequestInterceptor;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.context.annotation.*;
import org.springframework.web.context.request.*;
@Configuration
public class FeignClientConfig {
 @Bean public RequestInterceptor bearerTokenRequestInterceptor(){return template->{
  var attrs=RequestContextHolder.getRequestAttributes();
  if(attrs instanceof ServletRequestAttributes requestAttributes){
   HttpServletRequest request=requestAttributes.getRequest();
   String auth=request.getHeader("Authorization");
   if(auth!=null&&auth.startsWith("Bearer ")) template.header("Authorization",auth);
  }
 };}
}
