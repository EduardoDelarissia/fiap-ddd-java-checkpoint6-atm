package br.com.fiap.bank.mesa;
import java.util.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
@Controller public class MesaController {@GetMapping("/") public String home(){return "mesa";}}
@RestController @RequestMapping("/mesa/api") class MesaApiController {
 private final CreditoFeignClient client;
 MesaApiController(CreditoFeignClient client){this.client=client;}
 @GetMapping("/solicitacoes") List<Map<String,Object>> listar(){return client.listar();}
 @PutMapping("/solicitacoes/{id}/status") Map<String,Object> atualizar(@PathVariable Long id,@RequestBody Map<String,String> body){return client.mudar(id,body);}
}
