package br.com.fiap.bank.mesa;
import java.util.List;
import java.util.Map;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
@FeignClient(name="credito",url="${credito.url}",configuration=FeignClientConfig.class)
public interface CreditoFeignClient {
 @GetMapping("/api/v1/solicitacoes") List<Map<String,Object>> listar();
 @PutMapping("/api/v1/solicitacoes/{id}/status") Map<String,Object> mudar(@PathVariable("id") Long id,@RequestBody Map<String,String> body);
}
