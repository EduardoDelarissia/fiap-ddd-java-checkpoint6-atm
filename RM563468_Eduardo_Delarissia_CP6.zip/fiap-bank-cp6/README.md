# FIAP Bank — Checkpoint 6 — Domain Driven Design (Java)

**Aluno:** Eduardo Antonio Delarissia — **RM:** 563468  
**Professor:** Eduardo dos Santos Ramos — **Turma:** 2ESPG  
**Curso:** Engenharia de Software, FIAP

> Projeto de demonstração **novo**, construído a partir do enunciado do CP6. **Não substitui automaticamente o código do Checkpoint 5**; contratos e regras antigas precisam ser comparados/adaptados. As integrações externas com Bureau, SCR e notificações não foram implementadas; o Core Bancário usa dados fictícios. Não use como sistema bancário real.

## Estrutura

- `fiap-bank-plataforma-credito/domain`: modelo de domínio puro, sem Spring Security.
- `fiap-bank-plataforma-credito/application`: regras de negócio independentes de Spring.
- `fiap-bank-plataforma-credito/presentation`: REST API, Resource Server, `SecurityFilterChain`, login de demonstração, JWT HS256, RBAC.
- `fiap-bank-core-bancario`: serviço ilustrativo de saldo (porta 8081).
- `fiap-bank-mesa-operacoes-credito`: Thymeleaf + OpenFeign + propagação Bearer (porta 8082).
- `fiap-bank-internet-banking-mobile`: exemplo Angular 20 (porta 4200) + HttpInterceptor.

## Requisitos

Java 21, Maven 3.9+, Node.js 20.19+ e npm (para Angular). Spring Boot 4.1.2 e Spring Cloud 2025.1.2.

## Rodar em terminais separados

```bash
cd fiap-bank-plataforma-credito && mvn -DskipTests install && cd presentation && mvn spring-boot:run
cd fiap-bank-core-bancario && mvn spring-boot:run
cd fiap-bank-mesa-operacoes-credito && mvn spring-boot:run
cd fiap-bank-internet-banking-mobile && npm install && npm start
```

**Nota Maven:** a aplicação `presentation` depende de `domain` e `application`. Execute primeiro `mvn install` na raiz de `fiap-bank-plataforma-credito`.

## Testes automatizados

`cd fiap-bank-plataforma-credito && mvn test` executa o teste JUnit da camada de aplicação. Integração completa com JWT deve ser validada manualmente via Postman. A coleção `FIAP_Bank_CP6.postman_collection.json` pode ser importada no Postman e exige preencher a variável `token` após o login.

## Testes manuais / Postman

1. Envie `POST http://localhost:8080/api/auth/login`, `Content-Type: application/json`, body `{ "usuario":"cliente", "senha":"cliente123" }`. Copie `access_token`.
2. Envie `POST http://localhost:8080/api/v1/solicitacoes`, header `Authorization: Bearer SEU_TOKEN`, body `{ "valor": 4500 }`.
3. Envie `GET http://localhost:8080/api/v1/solicitacoes` com mesmo Bearer para consultar suas propostas.
4. Faça novo login `{ "usuario":"operador", "senha":"operador123" }` e envie `PUT http://localhost:8080/api/v1/solicitacoes/1/status` com Bearer do operador e body `{ "status":"APROVADA" }`.
5. Verifique `GET` sem token: 401; `PUT` com token do cliente: 403; token adulterado: 401; expiração: 401.
6. Mesa: abra `http://localhost:8082`, senha `operador123`, consulte propostas e atualize status.
7. Angular: `http://localhost:4200`, senha `cliente123`, solicite e consulte crédito.

## Segurança e limitações

- A Plataforma de Crédito usa `SessionCreationPolicy.STATELESS` e exige Bearer em cada chamada protegida.
- Claims: `iss`, `sub`, `iat`, `exp`, `cpf`, `conta`, `roles`, `scope`.
- Mapeamento: `roles` para `ROLE_ADMIN` / `ROLE_OPERADOR` e `scope` para `SCOPE_ROLE_CLIENTE`.
- O segredo de desenvolvimento é **público e inseguro**: defina `JWT_SECRET` com uma string aleatória de ao menos 32 caracteres antes de usar fora de demonstração. Não faça commit da chave real.
- Login com senhas fictícias em variáveis `DEMO_CLIENTE_PASSWORD` e `DEMO_OPERADOR_PASSWORD`: substitua por Authorization Server real, verificação de senha com hash e HTTPS em qualquer ambiente não didático.
- Dados de propostas ficam somente em memória (reiniciar apaga tudo). Isso **não é sessão de autenticação**, mas também não é persistência de crédito; para o CP5 existente, integre repositórios/JPA reais.
- O console H2 é permitido pela regra de segurança, mas não está instalado/habilitado neste exemplo. Em produção nunca exponha `/h2-console/**`.
- `frameOptions().sameOrigin()` permite frames apenas da mesma origem, mais seguro que `disable()` global. Para corresponder literalmente ao PDF, substitua pelo `disable()` apenas no ambiente local se o console H2 for usado.
- Token no `sessionStorage` do browser é conveniência de laboratório, requer mitigação de XSS e revisão de armazenamento de tokens em produção.
- CORS limitado a origens locais de demonstração. Revise conforme deploy.

## Entrega

1. Criar repositório GitHub monorepo; commitar código-fonte inclusive `src/main/java`.
2. Acrescentar integrantes e RMs reais ao README. Todos devem fazer seus próprios commits.
3. Confirmar build, demonstrar 401/403/200/201, tirar prints do Postman/telas.
4. Enviar ZIP e link GitHub pelo Teams na tarefa indicada no PDF (a folha cita **Checkpoint 4**; confirme com o professor, pois o documento inteiro trata do CP6).
5. Padrão do arquivo: `RM563468_Eduardo_Delarissia_CP6.zip`.
