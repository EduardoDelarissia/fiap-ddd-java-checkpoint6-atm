package br.com.fiap.bank.application;
import br.com.fiap.bank.domain.SolicitacaoCredito;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
public class CreditoService {
 private final Map<Long,SolicitacaoCredito> dados=new ConcurrentHashMap<>();
 private final AtomicLong sequencia=new AtomicLong();
 public SolicitacaoCredito criar(String cpf,String conta,BigDecimal valor){
  if(valor==null || valor.signum()<=0) throw new IllegalArgumentException("Valor deve ser positivo");
  long id=sequencia.incrementAndGet(); var s=new SolicitacaoCredito(id,cpf,conta,valor,"PENDENTE");dados.put(id,s);return s;
 }
 public List<SolicitacaoCredito> listar(String cpf,boolean operador){return dados.values().stream().filter(x->operador||x.cpf().equals(cpf)).sorted(Comparator.comparing(SolicitacaoCredito::id)).toList();}
 public Optional<SolicitacaoCredito> buscar(Long id){return Optional.ofNullable(dados.get(id));}
 public SolicitacaoCredito atualizar(Long id,String status){
  if(!List.of("APROVADA","REPROVADA").contains(status))throw new IllegalArgumentException("Status deve ser APROVADA ou REPROVADA");
  return dados.computeIfPresent(id,(k,s)->new SolicitacaoCredito(s.id(),s.cpf(),s.conta(),s.valor(),status));
 }
}
