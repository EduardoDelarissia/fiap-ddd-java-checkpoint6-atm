package br.com.fiap.bank.application;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class CreditoServiceTest {
 @Test void criarEAtualizar(){
  var service=new CreditoService();
  var proposta=service.criar("123","1",new BigDecimal("2000.00"));
  assertEquals("PENDENTE",proposta.status());
  assertEquals(1,service.listar("123",false).size());
  assertEquals(0,service.listar("999",false).size());
  assertEquals("APROVADA",service.atualizar(proposta.id(),"APROVADA").status());
 }
 @Test void rejeitaValorInvalido(){
  assertThrows(IllegalArgumentException.class,()->new CreditoService().criar("123","1",BigDecimal.ZERO));
 }
}
