package br.com.fiap.bank.domain;
import java.math.BigDecimal;
public record SolicitacaoCredito(Long id,String cpf,String conta,BigDecimal valor,String status) {}
