package br.com.fiap.bank.presentation;
import java.time.Instant;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.*;
import org.springframework.stereotype.Service;
@Service
public class TokenService {
 private final JwtEncoder encoder;
 @Value("${jwt.issuer}") private String issuer;
 @Value("${jwt.expiration-seconds}") private long expiration;
 public TokenService(JwtEncoder encoder){this.encoder=encoder;}
 public String gerarToken(String cpf,String conta,List<String> roles){
  Instant now=Instant.now(); boolean cliente=roles.contains("CLIENTE");
  var claims=JwtClaimsSet.builder().issuer(issuer).subject(cpf).issuedAt(now).expiresAt(now.plusSeconds(expiration))
   .claim("cpf",cpf).claim("conta",conta).claim("roles",roles).claim("scope",cliente?"ROLE_CLIENTE":"ROLE_OPERADOR").build();
  return encoder.encode(JwtEncoderParameters.from(JwsHeader.with(MacAlgorithm.HS256).build(),claims)).getTokenValue();
 }
}
