package br.com.fiap.bank.presentation;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import br.com.fiap.bank.application.CreditoService;
@SpringBootApplication
public class CreditoApp {public static void main(String[] args){SpringApplication.run(CreditoApp.class,args);}
 @Bean CreditoService creditoService(){return new CreditoService();}
}
