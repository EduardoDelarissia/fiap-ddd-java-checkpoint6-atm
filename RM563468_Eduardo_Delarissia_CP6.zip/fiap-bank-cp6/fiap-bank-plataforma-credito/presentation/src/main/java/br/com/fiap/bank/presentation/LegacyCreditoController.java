package br.com.fiap.bank.presentation;
import br.com.fiap.bank.application.CreditoService;
import br.com.fiap.bank.domain.SolicitacaoCredito;
import java.util.List;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/credito")
public class LegacyCreditoController {
 private final CreditoService credito;
 public LegacyCreditoController(CreditoService credito){this.credito=credito;}
 @GetMapping("/propostas") @PreAuthorize("hasAuthority('SCOPE_ROLE_CLIENTE') or hasRole('OPERADOR') or hasRole('ADMIN')")
 public List<SolicitacaoCredito> propostas(@AuthenticationPrincipal Jwt jwt){
  List<String> roles=jwt.getClaimAsStringList("roles");return credito.listar(jwt.getSubject(),roles!=null&&(roles.contains("OPERADOR")||roles.contains("ADMIN")));
 }
}
