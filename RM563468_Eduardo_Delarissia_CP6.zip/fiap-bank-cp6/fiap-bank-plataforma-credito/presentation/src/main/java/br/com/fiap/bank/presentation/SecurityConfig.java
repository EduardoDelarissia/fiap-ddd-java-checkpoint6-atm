package br.com.fiap.bank.presentation;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.crypto.spec.SecretKeySpec;
import com.nimbusds.jose.jwk.source.ImmutableSecret;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.*;
import org.springframework.security.oauth2.server.resource.authentication.*;
import org.springframework.security.web.SecurityFilterChain;
@Configuration @EnableWebSecurity @EnableMethodSecurity
public class SecurityConfig {
 @Value("${jwt.secret}") private String secret;
 @Value("${jwt.issuer}") private String issuer;
 @Bean SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
  return http.cors(org.springframework.security.config.Customizer.withDefaults())
   .csrf(csrf->csrf.disable())
   .headers(h->h.frameOptions(f->f.sameOrigin()))
   .sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
   .authorizeHttpRequests(a->a.requestMatchers("/api/auth/**","/h2-console/**").permitAll().anyRequest().authenticated())
   .oauth2ResourceServer(o->o.jwt(j->j.jwtAuthenticationConverter(jwtAuthenticationConverter()))).build();
 }
 @Bean JwtDecoder jwtDecoder(){
  var key=new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8),"HmacSHA256");
  var decoder=NimbusJwtDecoder.withSecretKey(key).macAlgorithm(MacAlgorithm.HS256).build();
  decoder.setJwtValidator(JwtValidators.createDefaultWithIssuer(issuer));return decoder;
 }
 @Bean JwtEncoder jwtEncoder(){return new NimbusJwtEncoder(new ImmutableSecret<>(secret.getBytes(StandardCharsets.UTF_8)));}
 @Bean JwtAuthenticationConverter jwtAuthenticationConverter(){
  var defaults=new JwtGrantedAuthoritiesConverter();
  var c=new JwtAuthenticationConverter();
  c.setJwtGrantedAuthoritiesConverter(jwt->{
    Collection<GrantedAuthority> result=new ArrayList<>(defaults.convert(jwt));
    List<String> roles=jwt.getClaimAsStringList("roles");
    if(roles!=null) for(String role:roles)result.add(new SimpleGrantedAuthority("ROLE_"+role.replaceFirst("^ROLE_","")));
    return result;
  });return c;
 }
}
