package br.com.fiap.bank.presentation;
import org.springframework.context.annotation.*;
import org.springframework.web.cors.*;
import org.springframework.web.servlet.config.annotation.*;
@Configuration public class CorsConfig implements WebMvcConfigurer {
 @Override public void addCorsMappings(CorsRegistry r){r.addMapping("/api/**").allowedOrigins("http://localhost:4200","http://localhost:8082").allowedMethods("GET","POST","PUT","OPTIONS").allowedHeaders("Authorization","Content-Type");}
}
