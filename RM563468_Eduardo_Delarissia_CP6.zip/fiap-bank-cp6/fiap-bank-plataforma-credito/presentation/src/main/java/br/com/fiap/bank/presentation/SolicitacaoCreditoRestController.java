package br.com.fiap.bank.presentation;
import br.com.fiap.bank.application.CreditoService;
import br.com.fiap.bank.domain.SolicitacaoCredito;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/v1/solicitacoes")
public class SolicitacaoCreditoRestController {
 private final CreditoService service;
 public SolicitacaoCreditoRestController(CreditoService service){this.service=service;}
 public record SolicitarCreditoRequest(@NotNull @DecimalMin("0.01") BigDecimal valor) {}
 public record StatusUpdateRequest(@NotBlank String status) {}
 @PostMapping @PreAuthorize("hasAuthority('SCOPE_ROLE_CLIENTE')")
 public ResponseEntity<SolicitacaoCredito> criarProposta(@AuthenticationPrincipal Jwt jwt,@Valid @RequestBody SolicitarCreditoRequest req){
  return ResponseEntity.status(HttpStatus.CREATED).body(service.criar(jwt.getSubject(),jwt.getClaimAsString("conta"),req.valor()));
 }
 @GetMapping @PreAuthorize("hasAuthority('SCOPE_ROLE_CLIENTE') or hasRole('OPERADOR') or hasRole('ADMIN')")
 public List<SolicitacaoCredito> listar(@AuthenticationPrincipal Jwt jwt){
  List<String> roles=jwt.getClaimAsStringList("roles");boolean operador=roles!=null&&(roles.contains("ADMIN")||roles.contains("OPERADOR"));
  return service.listar(jwt.getSubject(),operador);
 }
 @PutMapping("/{id}/status") @PreAuthorize("hasRole('ADMIN') or hasRole('OPERADOR')")
 public ResponseEntity<SolicitacaoCredito> atualizarStatus(@PathVariable Long id,@Valid @RequestBody StatusUpdateRequest req){
  var atualizado=service.atualizar(id,req.status());return atualizado==null?ResponseEntity.notFound().build():ResponseEntity.ok(atualizado);
 }
}
