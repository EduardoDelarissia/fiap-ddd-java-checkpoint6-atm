package br.com.fiap.bank.presentation;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
@RestController @RequestMapping("/api/auth")
public class AuthController {
 private final TokenService tokens;
 @Value("${demo.cliente-password}") private String clientePassword;
 @Value("${demo.operador-password}") private String operadorPassword;
 public AuthController(TokenService tokens){this.tokens=tokens;}
 public record LoginRequest(String usuario,String senha) {}
 public record TokenResponse(String access_token,String token_type) {}
 @PostMapping("/login") public ResponseEntity<TokenResponse> login(@RequestBody LoginRequest req){
  if(req==null||req.usuario()==null||req.senha()==null)return ResponseEntity.status(401).build();
  if(req.usuario().equals("cliente") && req.senha().equals(clientePassword))
   return ResponseEntity.ok(new TokenResponse(tokens.gerarToken("11122233344","0001",List.of("CLIENTE")),"Bearer"));
  if(req.usuario().equals("operador") && req.senha().equals(operadorPassword))
   return ResponseEntity.ok(new TokenResponse(tokens.gerarToken("99988877766","MESA",List.of("OPERADOR","ADMIN")),"Bearer"));
  return ResponseEntity.status(401).build();
 }
}
