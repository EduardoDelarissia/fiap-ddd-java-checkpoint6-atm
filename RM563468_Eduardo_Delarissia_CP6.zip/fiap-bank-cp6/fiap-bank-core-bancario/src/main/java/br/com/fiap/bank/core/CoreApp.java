package br.com.fiap.bank.core;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication public class CoreApp {public static void main(String[] args){SpringApplication.run(CoreApp.class,args);}}
