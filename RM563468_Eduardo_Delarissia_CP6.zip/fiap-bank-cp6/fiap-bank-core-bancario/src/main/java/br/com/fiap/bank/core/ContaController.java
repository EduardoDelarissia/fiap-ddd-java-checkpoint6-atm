package br.com.fiap.bank.core;
import java.math.BigDecimal;
import java.util.Map;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/contas")
public class ContaController {
 @GetMapping("/{numero}/saldo") public Map<String,Object> saldo(@PathVariable String numero){return Map.of("conta",numero,"saldo",new BigDecimal("15000.00"),"aviso","Dados fictícios para demonstração");}
}
