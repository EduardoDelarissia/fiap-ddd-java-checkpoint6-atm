# Casos de teste sugeridos
| Cenário | Resultado esperado |
| --- | --- |
| GET /api/v1/solicitacoes sem Bearer | 401 |
| Login cliente correto | 200 + JWT |
| Login com senha incorreta | 401 |
| POST proposta com cliente | 201 |
| POST proposta com operador | 403 |
| PUT status com cliente | 403 |
| PUT status com operador | 200 |
| PUT proposta inexistente com operador | 404 |
| GET com token corrompido | 401 |
| GET com token expirado | 401 |

Faça prints reais após iniciar os serviços: esses resultados não foram executados neste ambiente.
