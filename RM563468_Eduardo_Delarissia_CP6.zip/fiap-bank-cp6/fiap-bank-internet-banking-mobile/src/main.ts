import { bootstrapApplication } from '@angular/platform-browser';
import { Component, inject } from '@angular/core';
import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { authInterceptor } from './app/auth.interceptor';
@Component({selector:'app-root',standalone:true,imports:[FormsModule],template:`<main style="font:16px Arial;max-width:600px;margin:40px auto"><h1>FIAP Bank — Crédito</h1><p>Simulação educacional</p><input type="password" [(ngModel)]="senha" placeholder="Senha do cliente"><button (click)="login()">Entrar</button><hr><input type="number" [(ngModel)]="valor" placeholder="Valor"><button (click)="solicitar()">Solicitar crédito</button><button (click)="listar()">Minhas propostas</button><pre>{{saida}}</pre></main>`})
class App {http=inject(HttpClient);senha='';valor=1000;saida='';base='http://localhost:8080';
 login(){this.http.post<{access_token:string}>(this.base+'/api/auth/login',{usuario:'cliente',senha:this.senha}).subscribe({next:r=>{sessionStorage.setItem('access_token',r.access_token);this.saida='Autenticado'},error:e=>this.saida='Erro '+e.status});}
 solicitar(){this.http.post(this.base+'/api/v1/solicitacoes',{valor:this.valor}).subscribe({next:r=>this.saida=JSON.stringify(r,null,2),error:e=>this.saida='Erro '+e.status});}
 listar(){this.http.get(this.base+'/api/v1/solicitacoes').subscribe({next:r=>this.saida=JSON.stringify(r,null,2),error:e=>this.saida='Erro '+e.status});}}
bootstrapApplication(App,{providers:[provideHttpClient(withInterceptors([authInterceptor]))]}).catch(console.error);
