import { HttpInterceptorFn } from '@angular/common/http';
export const authInterceptor: HttpInterceptorFn = (request, next) => {
 const token=sessionStorage.getItem('access_token');
 const authReq=token?request.clone({setHeaders:{Authorization:`Bearer ${token}`}}):request;
 return next(authReq);
};
